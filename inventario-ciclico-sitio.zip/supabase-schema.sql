-- ============================================================
--  Inventarios CÍCLICOS · etcétera accesorios
--  Esquema Supabase. Tablas con prefijo cc_  (no toca las tablas
--  de la app de conteo físico: inventory_counts, zone_status, etc.)
--
--  Todo el acceso pasa por la función Netlify con la SERVICE KEY,
--  así que RLS queda activo SIN políticas públicas (el service_role
--  lo omite). El navegador nunca pega directo a estas tablas.
-- ============================================================

-- Tareas de conteo cíclico
create table if not exists cc_tareas (
  id          bigint generated always as identity primary key,
  nombre      text not null,
  filtros     jsonb not null default '{}'::jsonb,   -- {campo: [valores]}
  estado      text not null default 'activa',       -- activa | cerrada
  creada_por  text,
  created_at  timestamptz not null default now()
);

-- Productos (variantes) incluidos en cada tarea, con snapshot de identificadores
create table if not exists cc_tarea_producto (
  id           bigint generated always as identity primary key,
  tarea_id     bigint not null references cc_tareas(id) on delete cascade,
  product_id   integer not null,      -- product.product
  template_id  integer,               -- product.template
  name         text,
  default_code text,
  barcode      text,
  ident        jsonb,                 -- {x_familia_ident:..., ...}
  unique (tarea_id, product_id)
);
create index if not exists ix_cc_tp_tarea on cc_tarea_producto(tarea_id);

-- Sucursales asignadas a cada tarea + su estado
--   pendiente -> en_conteo -> terminada -> en_revision -> aprobada
create table if not exists cc_tarea_sucursal (
  id             bigint generated always as identity primary key,
  tarea_id       bigint not null references cc_tareas(id) on delete cascade,
  location_id    integer not null,    -- stock.location
  location_name  text,
  estado         text not null default 'pendiente',
  terminada_por  text,
  updated_at     timestamptz not null default now(),
  unique (tarea_id, location_id)
);
create index if not exists ix_cc_ts_tarea on cc_tarea_sucursal(tarea_id);
create index if not exists ix_cc_ts_loc on cc_tarea_sucursal(location_id);

-- Conteo capturado por cada sucursal para cada variante
create table if not exists cc_conteos (
  id          bigint generated always as identity primary key,
  tarea_id    bigint not null references cc_tareas(id) on delete cascade,
  location_id integer not null,
  product_id  integer not null,
  qty         numeric not null default 0,
  updated_at  timestamptz not null default now(),
  unique (tarea_id, location_id, product_id)
);
create index if not exists ix_cc_ct_tl on cc_conteos(tarea_id, location_id);

-- Resultado de la revisión por línea (aprobada / rechazada)
create table if not exists cc_revision (
  id           bigint generated always as identity primary key,
  tarea_id     bigint not null references cc_tareas(id) on delete cascade,
  location_id  integer not null,
  product_id   integer not null,
  estado       text not null,         -- aprobada | rechazada
  contado      numeric,
  teorico      numeric,
  revisada_por text,
  updated_at   timestamptz not null default now(),
  unique (tarea_id, location_id, product_id)
);
create index if not exists ix_cc_rev_tl on cc_revision(tarea_id, location_id);

-- RLS activo, sin políticas (solo service_role escribe/lee vía la función)
alter table cc_tareas          enable row level security;
alter table cc_tarea_producto  enable row level security;
alter table cc_tarea_sucursal  enable row level security;
alter table cc_conteos         enable row level security;
alter table cc_revision        enable row level security;
